OLD_GNUSTEP_STAMP_ASTRING = _Recycler-Recycler.tiff---
